/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommerceapp;

import java.util.Scanner;

/**
 *
 * @author Jack Behm
 */
public class ECommerceApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        bannerPrinter(); //prints banner
        boolean exists = getOrder(productsBuilder()); //runs get order string with the catalog as input
        if (exists == false) //termintates program if string inputted isn't catalogged
        {
            System.out.println("The product was not found.");
        }    
        if (exists == true) //program logic if user enters a catalogged item
        {
            double price = getPrice(); //get random price
            double tax = getTax(price); //calc tax on price
            double total = getTotal(price, tax); //add tax and price
            printTotal(total); //prints prorgams calculated price
        }
    }
    public static void bannerPrinter() { //prints banner
        System.out.println("*****************************************************");
        System.out.println("====== Welcome to Jack's eCommerce app! ======");
        System.out.println("*****************************************************");
        System.out.println();
    }
    public static String productsBuilder() {
        String productsCatalog = " Desk     " + " Table    " + " Pen      "; //products list (space added in the beginning to ensure that only the complete product name is valid (see line #52)
        return productsCatalog;
    }
    public static boolean getOrder(String orderStr) {
        Scanner in = new Scanner(System.in);
        boolean exists = false;
        System.out.println("Availiable products:"); //lists products availiable
        System.out.println("Desk     Pen     Table");
        System.out.println("");
        System.out.println("Enter a product (case sensitive):");
        String orderName = " " + in.next() + " "; //user input to be compared to catalog
        
        if (orderStr.indexOf(orderName) >= 0) //validates input string is in catalog
        {
            exists = true;
        }
        else //executed if input string isnt in catalog
        {
            exists = false;
        }
        return exists;
    }
    public static double getPrice() { //calcs price (random 1-100)
        double price = Math.random()*((100-1)+1)+1;
        return price;
    }
    public static double getTax(double price) { //calc tax
        double tax = price * .1;
        return tax;
    }
    public static double getTotal(double price, double tax) { //calcs total cost
        double total = price + tax;
        return total;
    }
    public static void printTotal (double total) {  //prints total price
        System.out.printf("Your sale total is: $%.2f", total);
    }
}
